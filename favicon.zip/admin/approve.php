
<?php 

/*Second
 * Get posted Data
 * by youngkunjez
 * date 20/09/2018
 */






if(isset($_POST['a'])){
    $post=$_POST['a'];

   var_dump($post);
   

}
    ?>
   