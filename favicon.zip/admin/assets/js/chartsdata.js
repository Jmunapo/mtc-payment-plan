
$.get("./account/logout.php", data=>{
        
});