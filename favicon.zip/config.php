<?php

define('ROOT', dirname(dirname(__FILE__)));
define('LOGIN', ROOT.'/account/login.php');

?>